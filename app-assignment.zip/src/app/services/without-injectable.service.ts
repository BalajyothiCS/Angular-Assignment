export class WithoutInjectableService {
  constructor() {}
  getData() {
    const data = [
      { a: 1, b: 3 },
      { a: 2, b: 4 },
    ];
    return data;
  }
}
