import { Component } from '@angular/core';
import { ComponentLevelService } from './comp-level.service';

@Component({
  selector: 'app-comp-level',
  template: `<p>Component Level Service</p>
    <input type="text" [(ngModel)]="name" appborder="name" />
    <table class="table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Age</th>
        </tr>
      </thead>
      <tbody>
        <tr *ngFor="let student of details?.studentDetails">
          <td>{{ student.name }}</td>
          <td>{{ student.age }}</td>
        </tr>
      </tbody>
    </table>`,
  providers: [ComponentLevelService],
})
export class ComponentLevelComponent {
  details;
  name;
  constructor(private service: ComponentLevelService) {}

  ngOnInit() {
    this.service.getStudentDetails().subscribe((res) => {
      this.details = res;
    });
  }
}
