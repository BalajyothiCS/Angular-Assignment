import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class ComponentLevelService {
  constructor(private http: HttpClient) {}
  getStudentDetails() {
    return this.http.get('/assets/mockresp/studentdetails.json');
  }
}
