import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { BorderDirective } from './directives/border.directive';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PhonePipe } from './pipes/phone.pipe';
import { SenderComponent } from './subjects/sender.component';
import { ReceiverComponent } from './subjects/receiver.component';
import { ObservablePromiseComponent } from './observables/observable-promise.component';
import { ObservableOperatorComponent } from './observables/observable-operator.component';
import { SubjectComponent } from './subjects/subject.component';
import { ComponentLevelComponent } from './services/complevel/comp-level.component';
import { LoginComponent } from './login-template-driven-form/login.component';
import { PswdValidatorDirective } from './validators/pswdvalidator.directive';
import { StudentComponent } from './student-reactive-form/student.component';
import { StudentDetailsComponent } from './studentdetails/student-details.component';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { CreatePromiseComponent } from './promises/create-promise.component';
import { ParentComponent } from './ngdocheck/parent.component';
import { ChildComponent } from './ngdocheck/child.component';

@NgModule({
  declarations: [
    AppComponent,
    ComponentLevelComponent,
    SenderComponent,
    ReceiverComponent,
    ObservablePromiseComponent,
    PhonePipe,
    BorderDirective,
    ObservableOperatorComponent,
    SubjectComponent,
    LoginComponent,
    PswdValidatorDirective,
    StudentComponent,
    StudentDetailsComponent,
    HomeComponent,
    AdminComponent,
    CreatePromiseComponent,
    ParentComponent,
    ChildComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
