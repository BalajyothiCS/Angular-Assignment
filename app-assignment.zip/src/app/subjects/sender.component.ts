import { Component, OnInit } from '@angular/core';
import { MessageService } from './message.service';

@Component({
  selector: 'app-sender',
  template: `
    <input type="text" [(ngModel)]="textVal" />
    <button (click)="sendMessage()">Send Message</button>
  `,
})
export class SenderComponent implements OnInit {
  textVal;
  dropval;
  constructor(private msgService: MessageService) {}

  ngOnInit() {}

  sendMessage() {
    this.msgService.setMessage(this.textVal);
  }
}
