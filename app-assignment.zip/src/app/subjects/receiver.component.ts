import { Component, OnInit } from '@angular/core';
import { MessageService } from './message.service';
import { BehaviorSubject, Subject } from 'rxjs';

@Component({
  selector: 'app-receiver',
  template: `<p>Received Values</p>
    <p></p>
    <p>Subject : {{ displayval }}</p> `,
})
export class ReceiverComponent implements OnInit {
  displayval;

  constructor(private msgService: MessageService) {}

  ngOnInit() {
    this.msgService.message.subscribe((data) => {
      this.displayval = data;
    });
  }
}
