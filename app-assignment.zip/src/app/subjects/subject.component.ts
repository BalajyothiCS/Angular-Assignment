import { Component, OnInit } from '@angular/core';
import { Subject, BehaviorSubject, ReplaySubject } from 'rxjs';

@Component({
  selector: 'app-subj',
  template: ``,
})
export class SubjectComponent implements OnInit {
  constructor() {}

  ngOnInit() {
    /*Subjects */
    const subj = new Subject();
    subj.next(1);
    subj.subscribe((val) => console.log(val));
    subj.next(2);
    subj.next(4);
    /*Behaviour Subject */
    const behsubj = new BehaviorSubject(1);

    behsubj.subscribe((val) => console.log(val));

    /*Replay Subject */

    const repsubj = new ReplaySubject(2);
    repsubj.next(1);
    repsubj.next(2);
    repsubj.next(3);
    repsubj.next(4);

    repsubj.subscribe((val) => console.log(val));
  }
}
