import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin',
  template: `<h4>Admin Works</h4>`,
})
export class AdminComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
