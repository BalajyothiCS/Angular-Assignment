import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-create-prms',
  template: ``,
})
export class CreatePromiseComponent implements OnInit {
  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.getData().then((resp) => console.log(resp));
  }

  getData() {
    const promise = new Promise((resolve, reject) => {
      return this.http
        .get('/assets/mockresp/studentdetails.json')
        .toPromise()
        .then((resp) => {
          resolve(resp);
        });
    });
    return promise;
  }
}
