import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login-template-driven-form/login.component';
import { StudentComponent } from './student-reactive-form/student.component';
import { StudentDetailsComponent } from './studentdetails/student-details.component';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { AuthGuard } from './guards/auth-canactivate.guard';
import { CanDeactivateGuard } from './guards/candeactivate.guard';
import { AuthGuardCanLoad } from './guards/auth-canload.guard';
import { ParentComponent } from './ngdocheck/parent.component';

const routes: Routes = [
  {
    path: '',
    component: LoginComponent,
  },
  {
    path: 'home',
    component: HomeComponent,
  },
  {
    path: 'admin',
    component: AdminComponent,
    canActivate: [AuthGuard],
  },
  {
    path: 'student',

    children: [
      {
        path: '',
        component: StudentComponent,
        canDeactivate: [CanDeactivateGuard],
      },
      {
        path: 'details/:id',
        component: StudentDetailsComponent,
      },
    ],
  },
  {
    path: 'lazy',
    loadChildren: () => import('./lazy/lazy.module').then((m) => m.LazyModule),
    canLoad: [AuthGuardCanLoad],
  },
  {
    path: 'parent',
    component: ParentComponent,
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
