import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ageValidator } from '../validators/age.validator';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.scss'],
})
export class StudentComponent implements OnInit {
  studentForm: FormGroup;
  students;
  count: any = 1;
  constructor(public fb: FormBuilder) {}

  ngOnInit() {
    this.studentForm = this.fb.group({
      fname: ['', Validators.required],
      lname: ['', Validators.required],
      age: ['', ageValidator()],
    });
    this.students = [{ id: 1, fname: 'John', lname: 'A', age: 18 }];
  }
  save() {
    this.count++;
    let id = this.count;
    const result = { ...this.studentForm.value, id };
    this.students.push(result);
    this.studentForm.reset();
  }
}
