import { Directive, ElementRef, Input, HostListener } from '@angular/core';

@Directive({
  selector: '[appborder]',
})
export class BorderDirective {
  @Input() val;

  constructor(private ele: ElementRef) {}
  @HostListener('ngModelChange') onChange($event) {
    if (this.ele.nativeElement.value.length > 10)
      this.ele.nativeElement.style.borderColor = 'red';
    else this.ele.nativeElement.style.borderColor = '';
  }
}
