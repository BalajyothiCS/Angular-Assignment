import { RouterModule, Routes } from '@angular/router';

import { NgModule } from '@angular/core';
import { LazyComponent } from '../lazy-comp/lazy-comp.component';

const routes: Routes = [
  {
    path: '',
    component: LazyComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LazyRoutingModule {}
