import { Directive, Input } from '@angular/core';
import {
  Validator,
  AbstractControl,
  NG_VALIDATORS,
  ValidatorFn,
} from '@angular/forms';

@Directive({
  selector: '[pswdvalidtor]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: PswdValidatorDirective,
      multi: true,
    },
  ],
})
export class PswdValidatorDirective implements Validator {
  validate(control: AbstractControl): { [key: string]: any } | null {
    let regexp = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;
    const result = regexp.test(control.value);
    return !result ? { invalidPswd: true } : null;
  }
}
