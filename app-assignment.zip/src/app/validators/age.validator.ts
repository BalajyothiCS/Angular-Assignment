import { AbstractControl, ValidatorFn } from '@angular/forms';

export function ageValidator() {
  return (control: AbstractControl): { [key: string]: any } | null => {
    if (control.value >= 15 && control.value <= 20) return null;
    else return { invalidage: true };
  };
}
