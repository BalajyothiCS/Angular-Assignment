import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'phone',
})
export class PhonePipe implements PipeTransform {
  transform(num) {
    const val = num.toString();
    if (val.length === 10) {
      const areacode = val.slice(0, 3);
      const telno = `(${areacode})${val.slice(3, 6)}-${val.slice(-4)}`;
      return telno;
    }
    return num;
  }
}
