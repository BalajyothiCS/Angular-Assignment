import { CanDeactivate } from '@angular/router';
import { Injectable } from '@angular/core';
import { StudentComponent } from '../student-reactive-form/student.component';

@Injectable({
  providedIn: 'root',
})
export class CanDeactivateGuard implements CanDeactivate<StudentComponent> {
  canDeactivate(component: StudentComponent) {
    if (component.studentForm.dirty) {
      alert('Changes in progress');
      return false;
    }
    return true;
  }
}
