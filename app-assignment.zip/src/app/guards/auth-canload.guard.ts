import { Injectable } from '@angular/core';
import { CanLoad, Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class AuthGuardCanLoad implements CanLoad {
  constructor(private router: Router) {}
  canLoad() {
    if (sessionStorage.getItem('username') === 'admin') return true;
    else {
      alert('Access Denied - Only admin user has access');
      this.router.navigate(['']);
    }
  }
}
