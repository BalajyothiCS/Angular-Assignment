import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lazy',
  template: `<p>Component in Lazy Module</p>`,
})
export class LazyComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
