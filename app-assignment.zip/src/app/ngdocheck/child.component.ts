import { Component, Input, OnChanges } from '@angular/core';

@Component({
  selector: 'app-child',
  template: `<p>Customer Name : {{ custname }}</p>
    <p>Customer Id: {{ id }}</p>`,
})
export class ChildComponent {
  @Input() custDetails;
  custname;
  id;

  constructor() {}

  ngDoCheck() {
    this.custname = this.custDetails.name;
    this.id = this.custDetails.id;
  }
}
