import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  template: `<button class="btn btn-primary" (click)="changeDetails()">
      ChangeDetails
    </button>
    <app-child [custDetails]="customerDetails"></app-child>`,
})
export class ParentComponent implements OnInit {
  customerDetails;
  constructor() {}

  ngOnInit() {
    this.customerDetails = { name: 'John', id: 'cust-001' };
  }
  changeDetails() {
    this.customerDetails.name = 'Jyothi';
    this.customerDetails.id = '2';
  }
}
