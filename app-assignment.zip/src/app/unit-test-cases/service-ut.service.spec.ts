import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import { WithHttpService } from '../services/with-http.service';
describe('ServiceTestCase', () => {
  let service: WithHttpService;
  let httpMock: HttpTestingController;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
    });
    service = TestBed.inject(WithHttpService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });
  it('should get student details', () => {
    const details = { studentDetails: [{ name: 'Araha', age: 10 }] };

    service.getObjectDetails().subscribe((resp) => {
      expect(resp).toEqual(details);
    });

    let req = httpMock.expectOne('/assets/mockresp/studentdetails.json');
    expect(req.request.method).toBe('GET');
    req.flush(details);
    httpMock.verify();
  });
});
