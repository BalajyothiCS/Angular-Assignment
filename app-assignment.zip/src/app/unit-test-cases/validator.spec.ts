import { ageValidator } from '../validators/age.validator';
import { FormControl } from '@angular/forms';

describe('ValidatorTestCase', () => {
  const validator = ageValidator();
  const control = new FormControl('input');

  it('should return null if age group between 15 -20', () => {
    control.setValue('16');
    expect(validator(control)).toBeNull();
  });

  it('should return invalid age if age less than 15 or greater than 20', () => {
    control.setValue('10');
    expect(validator(control)).toEqual({ invalidage: true });
  });
});
