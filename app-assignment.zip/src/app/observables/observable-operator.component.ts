import { Component, OnInit } from '@angular/core';
import { of, merge, forkJoin } from 'rxjs';
import { map, filter, take } from 'rxjs/operators';

@Component({
  selector: 'app-obs-operator',
  template: ``,
})
export class ObservableOperatorComponent implements OnInit {
  constructor() {}

  ngOnInit() {
    const obs = of(1, 2, 3);
    /*Map Operator*/
    obs.pipe(map((val) => val * 10)).subscribe((data) => console.log(data));

    /*Filter Operator*/
    obs.pipe(filter((val) => val === 2)).subscribe((data) => console.log(data));

    /*take Operator*/

    obs.pipe(take(1)).subscribe((data) => console.log(data));
    /*Merge Operator*/

    const obs2 = of(4, 5, 6);

    merge(obs, obs2).subscribe((data) => console.log(data));
    /*forkJoin Operator */

    forkJoin(obs, obs2).subscribe((data) => console.log(data));
  }
}
