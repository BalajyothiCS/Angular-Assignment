import { Component, OnInit } from '@angular/core';
import { ObservablePromiseService } from './observable-promise.service';

@Component({
  selector: 'app-obs-promise',
  template: ``,
  providers: [ObservablePromiseService],
})
export class ObservablePromiseComponent implements OnInit {
  details;
  constructor(private service: ObservablePromiseService) {}

  ngOnInit() {
    this.service.getStudentDetails().then((resp) => {
      this.details = resp;
    });
  }
}
